import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/unit/**/*.test.ts'],
    testTimeout: 120_000,
    maxWorkers: 1,
    fileParallelism: false,
  },
});
