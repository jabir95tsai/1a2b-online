import './style.css';
import type { SoloView } from '../protocol/solo.ts';
import type { RoomView, RoomStep } from '../protocol/room.ts';
const app = document.querySelector<HTMLDivElement>('#app')!;
let mode = 'home', solo: SoloView | null = null, room: RoomView | null = null;
let socket: WebSocket | null = null, stopped = false, connected = false, busy = false, notice = '', invite = '';
let reconnectAttempts = 0;
let invitedCode = '';
const reasons: Record<string, string> = { solved: '猜中答案', draw: '同回合雙方命中', timeout: '回合逾時', disconnect: '離線超過寬限時間', abandoned: '玩家主動離開', cancelled: '等待逾時，對局取消' };
const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
async function api(path: string, body?: unknown) {
    const response = await fetch(`/api${path}`, { method: body === undefined ? 'GET' : 'POST', headers: body === undefined ? {} : { 'Content-Type': 'application/json' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const data = await response.json();
    if (!response.ok)
        throw new Error(data.error.message + (data.error.turns ? `（衝突步驟：${data.error.turns.join('、')}）` : ''));
    return data;
}
const codeInput = (label = '你的猜測', name = 'guess') => `<label>${label}<input name="${name}" inputmode="numeric" autocomplete="off" pattern="[0-9]{4}" minlength="4" maxlength="4" required placeholder="0123" aria-label="${label}"></label>`;
function history(rows: {
    guess: string;
    feedback: {
        a: number;
        b: number;
    };
    candidatesBefore?: number;
    candidatesAfter?: number;
}[]) {
    return rows.length ? `<ol class="history">${rows.map((r, i) => `<li><span class="index">${String(i + 1).padStart(2, '0')}</span><strong>${esc(r.guess)}</strong><span class="feedback">${r.feedback.a}A${r.feedback.b}B</span>${r.candidatesAfter !== undefined ? `<small>${r.candidatesBefore} → ${r.candidatesAfter} 組</small>` : ''}</li>`).join('')}</ol>` : '<p class="empty">第一條線索，從你的下一手開始。</p>';
}
function render() {
    const focused = document.activeElement as HTMLInputElement | HTMLSelectElement | null;
    const values = Array.from(app.querySelectorAll<HTMLInputElement | HTMLSelectElement>('input,select')).map(e => [e.name, e.value]);
    const focusName = focused?.name;
    app.innerHTML = `<header><a href="#" data-mode="home" class="brand">1A<span>2B</span><small>數字之間</small></a><nav><button data-mode="A">我來猜</button><button data-mode="B">電腦猜</button><button data-mode="C">好友對戰</button></nav></header><main><div class="eyebrow">FOUR DIGITS. ONE POSSIBILITY.</div><div id="notice" role="status">${esc(notice)}</div>${content()}</main><footer>4 位不重複數字 · 允許 0 開頭<br>A 代表位置也正確，B 代表數字正確、位置不同。</footer>`;
    for (const [name, value] of values) {
        const e = app.querySelector<HTMLInputElement | HTMLSelectElement>(`[name="${name}"]`);
        if (e)
            e.value = value!;
    }
    if (focusName)
        app.querySelector<HTMLInputElement>(`[name="${focusName}"]`)?.focus();
    app.querySelectorAll<HTMLButtonElement>('button[type="submit"]').forEach(e => e.disabled = busy || (mode === 'C' && !!room && !connected));
    // A WebSocket update may arrive before the matching HTTP response. Keep the
    // newly rendered form locked until that request has finished clearing inputs.
    app.querySelectorAll<HTMLInputElement | HTMLSelectElement>('input,select').forEach(e => e.disabled = busy || (mode === 'C' && !!room && !connected));
    updateClock();
}
function content(): string {
    if (mode === 'home')
        return `<section class="hero"><h1>四個數字。<br>一點直覺，<em>更多推理。</em></h1><p>把每一次猜測，變成更靠近答案的線索。</p><div class="tiles"><b>0</b><b>1</b><b>2</b><b>3</b><span>1A2B</span></div></section><div class="cards"><button data-mode="A"><small>01 / SOLO</small><h2>我來猜</h2><p>電腦藏好答案，換你逐步破解。</p><span>開始推理 ↗</span></button><button data-mode="B"><small>02 / SOLVER</small><h2>電腦猜</h2><p>看 5040 種可能，收斂成唯一答案。</p><span>挑戰電腦 ↗</span></button><button data-mode="C"><small>03 / TOGETHER</small><h2>好友對戰</h2><p>互猜對方答案，或同步挑戰同一道題。</p><span>邀請好友 ↗</span></button></div>`;
    if (mode === 'C')
        return room ? roomContent() : `<h1>好對手，<em>好線索。</em></h1><div class="columns"><section class="panel"><h2>建立房間</h2><form data-form="room-create"><label>對戰玩法<select name="kind"><option value="duel">互猜答案 · 輪流出手</option><option value="race">同步競速 · 每回合一起揭曉</option></select></label><p>同步競速每回合 60 秒。進行中只公開對手步數，結束後公開完整歷程。</p><button type="submit">建立房間 ↗</button></form></section><section class="panel"><h2>加入好友</h2><form data-form="room-join"><label>8 碼房間代碼<input name="code" value="${esc(invitedCode)}" minlength="8" maxlength="8" required autocomplete="off" placeholder="輸入房碼"></label><button type="submit">加入房間</button></form></section></div>`;
    if (solo && ((mode === 'A') === (solo.kind === 'A')))
        return soloContent();
    return `<h1>${mode === 'A' ? '你來找出<em>唯一答案。</em>' : '換電腦<em>讀懂你的線索。</em>'}</h1><section class="panel narrow"><form data-form="solo-create">${mode === 'A' ? '<label>猜測次數<select name="limit"><option value="10">最多 10 次</option><option value="custom">自訂次數</option><option value="unlimited">無限猜</option></select></label><label>自訂次數（選擇自訂時適用）<input name="count" type="number" min="1" max="1000" value="10"></label>' : '<label>模式<select name="kind"><option value="B-honest">誠實模式 · 自動回饋</option><option value="B-oral">口述模式 · 手動回饋</option></select></label><label>答案（誠實模式必填）<input name="answer" inputmode="numeric" maxlength="4" autocomplete="off" type="password" placeholder="四位不重複數字"></label><p>口述模式不需要輸入答案。所有計算都由伺服端完成。</p>'}<button type="submit">開始新局 ↗</button></form></section>`;
}
function soloContent() {
    const g = solo!;
    return `<div class="title-row"><h1>${g.kind === 'A' ? '輪到你的直覺。' : '可能性，逐步縮小。'}</h1><span class="badge">${g.steps} 步${g.maxGuesses ? ` / ${g.maxGuesses}` : ''}</span></div><div class="columns"><section class="panel"><h2>${g.status === 'finished' ? '本局結束' : g.kind === 'A' ? '下一手' : '電腦的猜測'}</h2>${g.status === 'finished' ? `<div class="digits">${esc(g.answer ?? '—')}</div><p>${({ won: '你猜中了！', lost: '本次機會已用完', solved: '電腦已找到答案', abandoned: '已結束這一局' } as Record<string, string>)[g.outcome!]}</p><button data-action="new-solo">再來一局</button>` : g.kind === 'A' ? `<form data-form="solo-guess">${codeInput()}<button type="submit">送出猜測</button></form>` : `<div class="digits" data-testid="pending">${esc(g.pendingGuess)}</div><p>目前剩餘 <b>${g.candidateCount}</b> 組可能</p>${g.kind === 'B-honest' ? '<form data-form="solo-next"><button type="submit">取得回饋與下一手</button></form>' : '<form data-form="feedback"><div class="inline"><label>A<input name="a" type="number" min="0" max="4" value="0" required></label><label>B<input name="b" type="number" min="0" max="4" value="0" required></label></div><button type="submit">送出回饋</button></form>'}`}${g.status === 'active' ? '<button class="quiet" data-action="abandon-solo">結束並揭曉</button>' : ''}${g.kind === 'B-oral' && g.status === 'active' && g.steps ? `<details><summary>修正先前回饋</summary><form data-form="correct"><label>步驟<input name="turn" type="number" min="1" max="${g.steps}" value="1" required></label><div class="inline"><label>A<input name="a" type="number" min="0" max="4" value="0" required></label><label>B<input name="b" type="number" min="0" max="4" value="0" required></label></div><button type="submit">重新計算</button></form></details>` : ''}</section><section class="panel"><h2>推理紀錄</h2>${history(g.history)}</section></div>`;
}
function roomContent() {
    const r = room!, g = r.game, opponent = r.players[r.you === 0 ? 1 : 0];
    const result = g?.result;
    const ending = result ? (result.reason === 'cancelled' ? '雙方逾時，本局取消' : result.winner === null ? '旗鼓相當，和局！' : result.winner === r.you ? '你贏了！' : '本局由對手獲勝') : '';
    return `<div class="title-row"><h1>${r.kind === 'duel' ? '互猜答案' : '同步競速'}</h1><span class="badge">${connected ? '已連線' : '連線中'} · 第 ${r.matchNumber} 局</span></div><section class="room-strip"><span>房碼 <strong>${r.code}</strong></span><button class="quiet" data-action="share">複製邀請</button><span>${opponent ? opponent.connected ? '對手在線' : '對手暫時離線' : '等待好友加入'}</span><b id="clock"></b></section>${!g ? '<section class="panel"><h2>留一個位置，給你的對手。</h2><p>分享邀請連結或房碼。等待室 10 分鐘後到期。</p></section>' : `<div class="columns"><section class="panel"><h2>${g.phase === 'finished' ? ending : g.phase === 'setup' ? '先藏好你的答案' : `第 ${g.round} 回合`}</h2>${g.phase === 'finished' ? `<p>答案：${g.answers?.map(a => esc(a ?? '未設定')).join(' / ')}</p><p>原因：${esc(reasons[result?.reason ?? ''])}</p><form data-form="rematch"><button type="submit">${r.players[r.you]?.rematch ? '取消再戰邀請' : '再來一局'}</button></form><p>${opponent?.rematch ? '對手已同意再戰' : '等待雙方同意後開始新局'}</p>` : g.canSetAnswer ? `<form data-form="answer">${codeInput('你的秘密答案', 'answer')}<button type="submit">確認答案</button></form>` : g.canGuess ? `<form data-form="room-guess">${codeInput()}<button type="submit">鎖定這一手</button></form>` : `<p class="waiting">${g.myPending ? `已鎖定 ${esc(g.myPending)}，等待對手。` : '等待對手完成操作。'}</p>`}<h3>我的紀錄</h3>${history(g.myHistory)}</section><section class="panel"><h2>對手的進度 <span class="badge">${g.opponentSteps} 步</span></h2>${g.opponentHistory ? history(g.opponentHistory as RoomStep[]) : '<div class="privacy"><span>◈</span><h3>線索，各自保留。</h3><p>這一局結束後，就能一起回顧雙方的完整推理。</p></div>'}</section></div>`}<button class="quiet" data-action="leave-room">${g?.phase === 'finished' ? '離開房間' : '離開並結束對戰'}</button>`;
}
function updateClock() { const el = document.querySelector('#clock'); if (el && room) {
    const deadline = room.game?.deadline ?? room.expiresAt;
    el.textContent = deadline ? `${Math.max(0, Math.ceil((deadline - Date.now()) / 1000))} 秒` : '';
} }
function applyRoom(next: RoomView) { if (!room || room.incarnation !== next.incarnation || next.revision >= room.revision)
    room = next; render(); }
function connect() {
    if (!room || stopped)
        return;
    const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/api/rooms/${room.code}/ws`);
    socket = ws;
    ws.onmessage = e => { if (socket !== ws || e.data === 'pong')
        return; const message = JSON.parse(e.data); if (message.type === 'room') {
        connected = true;
        reconnectAttempts = 0;
        applyRoom(message.room);
    }
    else if (message.type === 'replaced') {
        stopped = true;
        connected = false;
        notice = '已在其他視窗開啟。此分頁已停止操作。';
        render();
    }
    else if (message.type === 'expired') {
        stopped = true;
        connected = false;
        notice = '房間已回收。';
        room = null;
        localStorage.removeItem('room');
        render();
    } };
    ws.onclose = () => { if (socket !== ws)
        return; connected = false; render(); if (!stopped)
        setTimeout(() => { if (socket === ws && !stopped)
            connect(); }, Math.min(30000, 1500 * 2 ** reconnectAttempts++)); };
}
async function soloAction(action: Record<string, unknown>) { const g = solo!; solo = (await api(`/solo/${g.id}/actions`, { requestId: crypto.randomUUID(), generation: g.generation, expectedRevision: g.revision, ...action })).game; }
async function roomAction(action: Record<string, unknown>) { const r = room!; applyRoom((await api(`/rooms/${r.code}/actions`, { requestId: crypto.randomUUID(), incarnation: r.incarnation, gameId: r.gameId, connectionEpoch: r.connectionEpoch, ...action })).room); }
async function run(work: () => Promise<void>) { if (busy)
    return; busy = true; notice = ''; render(); try {
    await work();
}
catch (e) {
    notice = e instanceof Error ? e.message : '連線失敗，請重試。';
}
finally {
    busy = false;
    render();
} }
app.addEventListener('submit', e => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const data = new FormData(form);
    const get = (k: string) => String(data.get(k) ?? '');
    void run(async () => {
        switch (form.dataset.form) {
            case 'solo-create':
                solo = (await api('/solo', { requestId: crypto.randomUUID(), ...(mode === 'A' ? { kind: 'A', maxGuesses: get('limit') === 'unlimited' ? null : get('limit') === 'custom' ? Number(get('count')) : 10 } : { kind: get('kind'), ...(get('kind') === 'B-honest' ? { answer: get('answer') } : {}) }) })).game;
                localStorage.setItem('solo', solo!.id);
                form.reset();
                break;
            case 'solo-guess':
                await soloAction({ type: 'guess', guess: get('guess') });
                break;
            case 'solo-next':
                await soloAction({ type: 'next' });
                break;
            case 'feedback':
                await soloAction({ type: 'feedback', feedback: { a: Number(get('a')), b: Number(get('b')) } });
                break;
            case 'correct':
                await soloAction({ type: 'correct', turn: Number(get('turn')), feedback: { a: Number(get('a')), b: Number(get('b')) } });
                break;
            case 'room-create': {
                const result = await api('/rooms', { requestId: crypto.randomUUID(), kind: get('kind') });
                room = result.room;
                localStorage.setItem('room', room!.code);
                stopped = false;
                connect();
                break;
            }
            case 'room-join':
                room = (await api(`/rooms/${get('code').toUpperCase()}/join`, invite && get('code').toUpperCase() === invitedCode ? { inviteToken: invite } : {})).room;
                localStorage.setItem('room', room!.code);
                stopped = false;
                connect();
                break;
            case 'answer':
                await roomAction({ type: 'set-answer', round: room!.game!.round, answer: get('answer') });
                break;
            case 'room-guess':
                await roomAction({ type: 'guess', round: room!.game!.round, guess: get('guess') });
                break;
            case 'rematch':
                await roomAction({ type: 'rematch', accept: !room!.players[room!.you]!.rematch });
                break;
        }
        app.querySelectorAll<HTMLInputElement>('input[name="guess"],input[name="answer"]').forEach(i => i.value = '');
    });
});
app.addEventListener('click', e => { const button = (e.target as Element).closest<HTMLElement>('[data-mode],[data-action]'); if (!button)
    return; e.preventDefault(); if (button.dataset.mode) {
    mode = button.dataset.mode;
    notice = '';
    render();
    return;
} void run(async () => { switch (button.dataset.action) {
    case 'new-solo':
        solo = null;
        localStorage.removeItem('solo');
        break;
    case 'abandon-solo':
        if (confirm('結束這一局並揭曉答案？'))
            await soloAction({ type: 'abandon' });
        break;
    case 'share': {
        const shareToken = (await api('/rooms/' + room!.code + '/invite')).inviteToken;
        await navigator.clipboard.writeText(`${location.origin}/#join=${room!.code}.${shareToken}`);
        notice = '邀請連結已複製';
        break;
    }
    case 'leave-room':
        if (room?.game?.phase !== 'finished' && !confirm('離開將結束這一局，確定離開？'))
            return;
        if (room?.life === 'active' || room?.life === 'waiting')
            await roomAction({ type: 'leave' });
        stopped = true;
        socket?.close();
        socket = null;
        room = null;
        connected = false;
        localStorage.removeItem('room');
        break;
} }); });
setInterval(() => { updateClock(); if (socket?.readyState === WebSocket.OPEN)
    socket.send('ping'); }, 25000);
setInterval(updateClock, 1000);
render();
void run(async () => { await api('/session', {}); if (readInvite())
    return; const savedRoom = localStorage.getItem('room'); if (savedRoom) {
    try {
        room = (await api(`/rooms/${savedRoom}`)).room;
        mode = 'C';
        connect();
    }
    catch {
        localStorage.removeItem('room');
    }
} const savedSolo = localStorage.getItem('solo'); if (savedSolo) {
    try {
        solo = (await api(`/solo/${savedSolo}`)).game;
        if (!room)
            mode = solo!.kind === 'A' ? 'A' : 'B';
    }
    catch {
        localStorage.removeItem('solo');
    }
} });
function historyReplace() { window.history.replaceState(null, '', location.pathname); }
function readInvite(): boolean {
    const fragment = /^#join=([23456789ABCDEFGHJKMNPQRSTUVWXYZ]{8})(?:\.([a-f0-9]{64}))?$/.exec(location.hash);
    if (!fragment)
        return false;
    historyReplace();
    mode = 'C';
    invite = fragment[2] ?? '';
    invitedCode = fragment[1]!;
    if (room && room.code !== invitedCode)
        notice = '請先離開目前房間，再加入邀請的房間。';
    render();
    const input = app.querySelector<HTMLInputElement>('[name="code"]');
    if (input)
        input.value = invitedCode;
    return true;
}
window.addEventListener('hashchange', readInvite);
